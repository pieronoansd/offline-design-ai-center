export default function Extension(){
return <main style={{padding:40}}>🐭 圆圆鼠 延展生产中心</main>
}