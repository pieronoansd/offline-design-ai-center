export default function Visual(){
return <main style={{padding:40}}>🐒 方块猴 AI主视觉生成中心</main>
}