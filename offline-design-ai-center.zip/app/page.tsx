export default function Home(){
return <main style={{padding:40}}>OFFLINE DESIGN AI CENTER V1.0</main>
}