export const IP_LIBRARY=[
{name:'方块猴',theme:'red'},
{name:'圆圆鼠',theme:'yellow'},
{name:'三角兔',theme:'pink'}
]
